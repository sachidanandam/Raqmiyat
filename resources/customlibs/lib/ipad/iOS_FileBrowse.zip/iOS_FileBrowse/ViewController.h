//
//  ViewController.h
//  AssetLibrary
//
//  Created by Admin on 12/18/14.
//  Copyright (c) 2014 Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>


@interface ViewController : UIViewController

@property(nonatomic,retain) NSMutableArray *imageArray;
@property(nonatomic,strong) NSArray *imageArrayValues;
@property(nonatomic,strong) NSArray *arrayValues;
@property(nonatomic,retain) NSMutableArray *contentArray;

// Final Values
@property(nonatomic,retain) NSMutableArray *base64ArrayValues;
@property(nonatomic,retain) NSMutableDictionary *concatArrayValues ;

-(void)testing;
-(void) retriveGalleryPictures;
-(NSString *) convertUIImageIntoByteArray:(int)selectedValue;
@end
