//
//  ViewController.m
//  AssetLibrary
//
//  Created by Admin on 12/18/14.
//  Copyright (c) 2014 Admin. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController
+ (id)init{
    //NSLog(@"InitCalled");
    ViewController* jsObj = [[ViewController alloc] init];
    [jsObj viewDidLoad];
    return jsObj;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //NSLog(@"didloadCalled");
    self.arrayValues = [NSArray array];
    self.imageArrayValues = [NSArray array];
    self.contentArray = [NSMutableArray array];
    self.imageArray = [NSMutableArray array];
    // Final Values
    self.base64ArrayValues = [NSMutableArray array];
    self.concatArrayValues = [[NSMutableDictionary alloc] init];
    
    [self retriveGalleryPictures];
   
    
    
    /*UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [button addTarget:self
               action:@selector(testing)
     forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"Show View" forState:UIControlStateNormal];
    button.frame = CGRectMake(80.0, 210.0, 160.0, 40.0);
    [self.view addSubview:button];*/
    
    //NSLog(@"Testing FFI");
    //[self retriveGalleryPictures];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)testing {
    
    //[self returnArrayValuesToKony];
    [self returnArrayValues];
}

-(void) retriveGalleryPictures {
    //NSLog(@"testingretrivegallery");
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc]init];

    
        [library enumerateGroupsWithTypes:ALAssetsGroupAll usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
            if (group) {
                [group setAssetsFilter:[ALAssetsFilter allPhotos]];
                [group enumerateAssetsUsingBlock:^(ALAsset *asset, NSUInteger index, BOOL *stop){
                    if (asset){
                        NSString *fileName = asset.defaultRepresentation.filename;
                        [self.contentArray addObject:fileName];
                        UIImage *image = [UIImage imageWithCGImage:[asset thumbnail]];
                        [self.imageArray addObject:image];
                    }
                }];
            }
        } failureBlock:^(NSError *error) {
        }];

}

-(NSDictionary *) returnArrayValues {
    self.arrayValues = [self.contentArray copy];
    self.imageArrayValues = [self.imageArray copy];
    
    for (int i = 0; i<[self.imageArrayValues count]; i++) {
        
      NSString *returnValues =   [self convertUiImageIntoBase64:self.imageArrayValues[i]];
        [self.base64ArrayValues  addObject:returnValues];
    }
    [self.concatArrayValues setObject:self.base64ArrayValues forKey:@"ImageEncode"];
    [self.concatArrayValues setObject:self.arrayValues forKey:@"ImageName"];
    NSDictionary *finalArrayValues = [self.concatArrayValues copy];
    
    return finalArrayValues;
}

-(NSString *) convertUiImageIntoBase64:(UIImage *)selectedImage {
    
    // Converting UIImage Into Base64Encoding
    NSData *imageData = UIImagePNGRepresentation(selectedImage);
    NSString *encodedDate = [imageData base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];
   
    return encodedDate;
    
}

@end
